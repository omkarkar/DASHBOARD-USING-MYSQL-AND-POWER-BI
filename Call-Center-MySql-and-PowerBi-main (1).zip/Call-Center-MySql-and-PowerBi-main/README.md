# Call-Center-MySql-and-PowerBi
Executed Academic project to create a Call Center SQL Query Report and Call Center Dashboard using Call-Center Database. 
These Query is written to got in result the data and information which is useful to citizens, industry, data users, and policy makers. Dashboard is designed to provide high quality information in visual overview of data, using Column, Bar, Area, Donut, Tree, Cards, Filters.
